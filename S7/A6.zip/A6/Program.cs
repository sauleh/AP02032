﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A6;

public class Program
{
    static void Main(string[] args)
    { }

    public static int GetObjectType(object o)
    {
        throw NotImplementedException();
    }

    public static bool IdealHusband(FutureHusbandType fht)
    {
        throw NotImplementedException();
    }
}
